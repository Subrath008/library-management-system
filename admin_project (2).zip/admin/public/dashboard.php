<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/Dashboard.php';
require_admin();

$pageTitle = 'Dashboard';
$stats = Dashboard::stats();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/dashboard.php';
require_once __DIR__ . '/../views/layout/footer.php';

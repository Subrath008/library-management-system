<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/User.php';
require_admin();

if (isset($_GET['action'], $_GET['id'])) {
    $id = (int)$_GET['id'];

    if ($id === (int)$_SESSION['user_id']) {
        set_flash('error', 'You cannot change your own active status.');
    } elseif ($_GET['action'] === 'activate') {
        User::setActive($id, 1);
        log_action('Activated user ID ' . $id);
        set_flash('success', 'User activated successfully.');
    } elseif ($_GET['action'] === 'deactivate') {
        User::setActive($id, 0);
        log_action('Deactivated user ID ' . $id);
        set_flash('success', 'User deactivated successfully.');
    }
    redirect('users.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_role'])) {
    $id = (int)($_POST['user_id'] ?? 0);
    $role = $_POST['role'] ?? '';
    $allowedRoles = ['member', 'librarian', 'branch_manager', 'admin'];

    if ($id <= 0 || !in_array($role, $allowedRoles, true)) {
        set_flash('error', 'Invalid role update request.');
    } else {
        User::changeRole($id, $role);
        log_action('Changed role of user ID ' . $id . ' to ' . $role);
        set_flash('success', 'User role updated successfully.');
    }
    redirect('users.php');
}

$pageTitle = 'Users';
$users = User::all();
$flash = get_flash();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/users.php';
require_once __DIR__ . '/../views/layout/footer.php';

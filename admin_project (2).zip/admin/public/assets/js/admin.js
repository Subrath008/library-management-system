document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('userSearch');
    const tableBody = document.getElementById('userTableBody');

    if (!searchInput || !tableBody) {
        return;
    }

    searchInput.addEventListener('keyup', function () {
        const query = searchInput.value.trim();

        fetch('ajax/user_search.php?q=' + encodeURIComponent(query))
            .then(response => response.json())
            .then(users => {
                tableBody.innerHTML = '';

                if (!Array.isArray(users) || users.length === 0) {
                    tableBody.innerHTML = '<tr><td colspan="9">No users found.</td></tr>';
                    return;
                }

                users.forEach(user => {
                    const status = Number(user.is_active) === 1
                        ? '<span class="badge success">Active</span>'
                        : '<span class="badge danger">Inactive</span>';

                    const currentUserId = window.currentAdminId || 0;
                    let action = '<span class="muted">Current admin</span>';

                    if (Number(user.id) !== Number(currentUserId)) {
                        action = Number(user.is_active) === 1
                            ? `<a class="btn danger small" href="users.php?action=deactivate&id=${user.id}">Deactivate</a>`
                            : `<a class="btn success small" href="users.php?action=activate&id=${user.id}">Activate</a>`;
                    }

                    const roles = ['member', 'librarian', 'branch_manager', 'admin'];
                    let roleOptions = '';
                    roles.forEach(role => {
                        const selected = user.role === role ? 'selected' : '';
                        roleOptions += `<option value="${escapeHtml(role)}" ${selected}>${escapeHtml(role)}</option>`;
                    });

                    tableBody.innerHTML += `
                        <tr>
                            <td>${escapeHtml(user.id)}</td>
                            <td>${escapeHtml(user.name)}</td>
                            <td>${escapeHtml(user.email)}</td>
                            <td>${escapeHtml(user.phone || '')}</td>
                            <td>${escapeHtml(user.role)}</td>
                            <td>${escapeHtml(user.branch_name || '-')}</td>
                            <td>${status}</td>
                            <td>
                                <form method="post" class="inline-form">
                                    <input type="hidden" name="user_id" value="${escapeHtml(user.id)}">
                                    <select name="role" required>${roleOptions}</select>
                                    <button type="submit" name="change_role" class="btn small">Save</button>
                                </form>
                            </td>
                            <td>${action}</td>
                        </tr>
                    `;
                });
            })
            .catch(() => {
                tableBody.innerHTML = '<tr><td colspan="9">Search failed. Please try again.</td></tr>';
            });
    });
});

function escapeHtml(value) {
    if (value === null || value === undefined) {
        return '';
    }

    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

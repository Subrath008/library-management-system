<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/Book.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_book'])) {
    $id = (int)($_POST['book_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $genreId = (int)($_POST['genre_id'] ?? 0);
    $publisher = trim($_POST['publisher'] ?? '');
    $year = trim($_POST['published_year'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $isAvailable = (int)($_POST['is_available'] ?? 0);

    if ($id <= 0 || $title === '' || $author === '' || $genreId <= 0) {
        set_flash('error', 'Title, author, and genre are required.');
    } else {
        Book::update($id, $title, $author, $isbn, $genreId, $publisher, $year, $description, $isAvailable);
        log_action('Updated book ID ' . $id);
        set_flash('success', 'Book updated successfully.');
    }
    redirect('books.php');
}

$pageTitle = 'Global Catalog';
$editBook = isset($_GET['edit']) ? Book::find((int)$_GET['edit']) : null;
$books = Book::all();
$genres = Book::genres();
$flash = get_flash();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/books.php';
require_once __DIR__ . '/../views/layout/footer.php';

<?php
require_once __DIR__ . '/../config/functions.php';

if (isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'admin') {
    redirect('dashboard.php');
}

redirect('login.php');

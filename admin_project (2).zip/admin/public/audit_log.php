<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/AuditLog.php';
require_admin();

$pageTitle = 'Audit Log';
$logs = AuditLog::lines();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/audit_log.php';
require_once __DIR__ . '/../views/layout/footer.php';

<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/User.php';

if (isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'admin') {
    redirect('dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = 'Email and password are required.';
    } else {
        $user = User::findByEmail($email);

        if (!$user || !password_matches_existing_sql($password, $user['password_hash'])) {
            $error = 'Invalid email or password.';
        } elseif ((int)$user['is_active'] !== 1) {
            $error = 'This account is deactivated.';
        } elseif ($user['role'] !== 'admin') {
            $error = 'Only admin users can access this panel.';
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            log_action('Logged in to admin panel');
            redirect('dashboard.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-card">
        <h1>Library Admin Login</h1>
        <p class="muted">Use your admin account to continue.</p>
        <?php if ($error): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>
        <form method="post">
            <label>Email</label>
            <input type="email" name="email" value="admin@gmail.com" required>
            <label>Password</label>
            <input type="password" name="password" value="123456" required>
            <button type="submit" class="btn full">Login</button>
        </form>
    </div>
</body>
</html>

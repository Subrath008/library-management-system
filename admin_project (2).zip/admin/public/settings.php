<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/Branch.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_policy'])) {
    $policyId = (int)($_POST['policy_id'] ?? 0);
    $maxBorrowDays = (int)($_POST['max_borrow_days'] ?? 0);
    $maxBooks = (int)($_POST['max_books_per_member'] ?? 0);
    $fineRate = (float)($_POST['fine_rate_per_day'] ?? 0);
    $maxRenewals = (int)($_POST['max_renewals'] ?? 0);

    if ($policyId <= 0 || $maxBorrowDays <= 0 || $maxBooks <= 0 || $fineRate < 0 || $maxRenewals < 0) {
        set_flash('error', 'Please enter valid policy values.');
    } else {
        Branch::updatePolicy($policyId, $maxBorrowDays, $maxBooks, $fineRate, $maxRenewals);
        log_action('Updated branch policy ID ' . $policyId);
        set_flash('success', 'Policy updated successfully.');
    }
    redirect('settings.php');
}

$pageTitle = 'Policies / Settings';
$policies = Branch::policies();
$flash = get_flash();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/settings.php';
require_once __DIR__ . '/../views/layout/footer.php';

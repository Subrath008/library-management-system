<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/Dashboard.php';
require_once __DIR__ . '/../models/Report.php';
require_admin();

$pageTitle = 'Print Report';
$stats = Dashboard::stats();
$activeBranches = Report::mostActiveBranches();
$borrowedGenres = Report::mostBorrowedGenres();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/print_report.php';
require_once __DIR__ . '/../views/layout/footer.php';

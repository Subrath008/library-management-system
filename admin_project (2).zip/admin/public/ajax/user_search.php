<?php
require_once __DIR__ . '/../../config/functions.php';
require_once __DIR__ . '/../../models/User.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$keyword = trim($_GET['q'] ?? '');
$users = User::all($keyword);

echo json_encode($users);

<?php
require_once __DIR__ . '/../config/functions.php';
log_action('Logged out from admin panel');
session_destroy();
redirect('login.php');

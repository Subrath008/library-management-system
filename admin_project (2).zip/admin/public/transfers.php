<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/Report.php';
require_admin();

$pageTitle = 'Transfers';
$requests = Report::interBranchRequests();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/transfers.php';
require_once __DIR__ . '/../views/layout/footer.php';

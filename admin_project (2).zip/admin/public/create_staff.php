<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Branch.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role = $_POST['role'] ?? '';
    $branchId = (int)($_POST['branch_id'] ?? 0);
    $allowedRoles = ['librarian', 'branch_manager', 'admin'];

    if ($name === '' || $email === '' || $phone === '' || $password === '') {
        set_flash('error', 'All required fields must be filled.');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        set_flash('error', 'Please enter a valid email address.');
    } elseif (strlen($password) < 6) {
        set_flash('error', 'Password must be at least 6 characters.');
    } elseif (!in_array($role, $allowedRoles, true)) {
        set_flash('error', 'Invalid staff role selected.');
    } elseif (User::emailExists($email)) {
        set_flash('error', 'This email already exists.');
    } else {
        $branchValue = $branchId > 0 ? $branchId : null;
        if (User::createStaff($name, $email, $phone, $password, $role, $branchValue)) {
            log_action('Created new ' . $role . ' account: ' . $email);
            set_flash('success', 'Staff account created successfully.');
        } else {
            set_flash('error', 'Could not create staff account.');
        }
    }
    redirect('create_staff.php');
}

$pageTitle = 'Create Staff';
$branches = Branch::activeBranches();
$flash = get_flash();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/create_staff.php';
require_once __DIR__ . '/../views/layout/footer.php';

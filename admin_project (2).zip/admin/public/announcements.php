<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/Announcement.php';
require_admin();

if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete') {
    $id = (int)$_GET['id'];
    Announcement::delete($id);
    log_action('Deleted platform announcement ID ' . $id);
    set_flash('success', 'Announcement deleted successfully.');
    redirect('announcements.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_announcement'])) {
    $title = trim($_POST['title'] ?? '');
    $body = trim($_POST['body'] ?? '');

    if ($title === '' || $body === '') {
        set_flash('error', 'Title and body are required.');
    } else {
        Announcement::create((int)$_SESSION['user_id'], $title, $body);
        log_action('Created platform announcement: ' . $title);
        set_flash('success', 'Announcement published successfully.');
    }
    redirect('announcements.php');
}

$pageTitle = 'Announcements';
$announcements = Announcement::platformWide();
$flash = get_flash();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/announcements.php';
require_once __DIR__ . '/../views/layout/footer.php';

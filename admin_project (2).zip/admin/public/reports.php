<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/Report.php';
require_admin();

$pageTitle = 'Reports';
$monthlyBorrows = Report::monthlyBorrows();
$monthlyFines = Report::monthlyFinesCollected();
$activeBranches = Report::mostActiveBranches();
$borrowedGenres = Report::mostBorrowedGenres();
$memberGrowth = Report::memberGrowth();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/reports.php';
require_once __DIR__ . '/../views/layout/footer.php';

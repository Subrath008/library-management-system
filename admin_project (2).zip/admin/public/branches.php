<?php
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../models/Branch.php';
require_admin();

$pageTitle = 'Branches';
$branches = Branch::all();

require_once __DIR__ . '/../views/layout/header.php';
require_once __DIR__ . '/../views/layout/sidebar.php';
require_once __DIR__ . '/../views/admin/branches.php';
require_once __DIR__ . '/../views/layout/footer.php';

<aside class="sidebar">
    <h2>Library Admin</h2>
    <p class="admin-name"><?= e($_SESSION['name'] ?? 'Admin') ?></p>
    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="users.php">Users</a>
        <a href="create_staff.php">Create Staff</a>
        <a href="branches.php">Branches</a>
        <a href="books.php">Global Catalog</a>
        <a href="settings.php">Policies/Settings</a>
        <a href="transfers.php">Transfers</a>
        <a href="reports.php">Reports</a>
        <a href="announcements.php">Announcements</a>
        <a href="audit_log.php">Audit Log</a>
        <a href="print_report.php">Print Report</a>
        <a href="logout.php" class="logout">Logout</a>
    </nav>
</aside>
<main class="content">

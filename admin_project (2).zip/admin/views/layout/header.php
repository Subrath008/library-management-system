<?php $pageTitle = $pageTitle ?? 'Admin Panel'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - Library Admin</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="app">

<h1>Branch Overview</h1>
<p class="muted">View all branches, assigned managers, status, and librarian count.</p>

<div class="table-wrap">
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Branch</th>
            <th>City</th>
            <th>Address</th>
            <th>Phone</th>
            <th>Manager</th>
            <th>Librarians</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($branches as $branch): ?>
            <tr>
                <td><?= e($branch['id']) ?></td>
                <td><?= e($branch['name']) ?></td>
                <td><?= e($branch['city']) ?></td>
                <td><?= e($branch['address']) ?></td>
                <td><?= e($branch['phone']) ?></td>
                <td><?= e($branch['manager_name'] ?? 'Not Assigned') ?></td>
                <td><?= e($branch['librarian_count']) ?></td>
                <td><?= $branch['is_active'] ? '<span class="badge success">Active</span>' : '<span class="badge danger">Inactive</span>' ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

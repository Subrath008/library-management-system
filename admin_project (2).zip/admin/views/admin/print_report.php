<h1>Printable Admin Report Summary</h1>
<p class="muted">Use this page for printable/exportable report evidence.</p>
<button onclick="window.print()" class="btn print-hide">Print Report</button>

<h2>Dashboard Summary</h2>
<table>
    <tr><th>Total Members</th><td><?= e($stats['total_members']) ?></td></tr>
    <tr><th>Total Books</th><td><?= e($stats['total_books']) ?></td></tr>
    <tr><th>Total Branches</th><td><?= e($stats['total_branches']) ?></td></tr>
    <tr><th>Active Loans</th><td><?= e($stats['active_loans']) ?></td></tr>
    <tr><th>Overdue Loans</th><td><?= e($stats['overdue_loans']) ?></td></tr>
    <tr><th>Outstanding Fines</th><td><?= number_format((float)$stats['outstanding_fines'], 2) ?></td></tr>
</table>

<h2>Most Active Branches</h2>
<?php include __DIR__ . '/partials/active_branches.php'; ?>

<h2>Most Borrowed Genres</h2>
<?php include __DIR__ . '/partials/borrowed_genres.php'; ?>

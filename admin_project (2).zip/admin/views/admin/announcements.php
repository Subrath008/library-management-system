<h1>Platform-Wide Announcements</h1>
<p class="muted">Create announcements visible to the whole platform.</p>

<?php if ($flash): ?>
    <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>

<form method="post" class="form-card wide">
    <label>Title</label>
    <input type="text" name="title" required maxlength="255">

    <label>Body</label>
    <textarea name="body" rows="4" required></textarea>

    <button type="submit" name="create_announcement" class="btn">Publish Announcement</button>
</form>

<div class="table-wrap">
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Body</th>
            <th>Author</th>
            <th>Published</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($announcements as $announcement): ?>
            <tr>
                <td><?= e($announcement['id']) ?></td>
                <td><?= e($announcement['title']) ?></td>
                <td><?= e($announcement['body']) ?></td>
                <td><?= e($announcement['author_name'] ?? '-') ?></td>
                <td><?= e($announcement['published_at']) ?></td>
                <td><a class="btn danger small" href="announcements.php?action=delete&id=<?= e($announcement['id']) ?>">Delete</a></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

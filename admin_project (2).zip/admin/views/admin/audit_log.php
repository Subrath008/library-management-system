<h1>Audit Log</h1>
<p class="muted">This log records important actions made inside this Admin module.</p>

<div class="log-box">
    <?php if (empty($logs)): ?>
        <p>No audit log records yet.</p>
    <?php else: ?>
        <?php foreach ($logs as $line): ?>
            <div><?= e($line) ?></div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

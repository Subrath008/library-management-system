<h1>Inter-Branch Transfer Requests</h1>
<p class="muted">View all transfer requests across the platform.</p>

<div class="table-wrap">
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Book</th>
            <th>From Branch</th>
            <th>To Branch</th>
            <th>Requested By</th>
            <th>Status</th>
            <th>Created</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($requests as $request): ?>
            <tr>
                <td><?= e($request['id']) ?></td>
                <td><?= e($request['book_title']) ?></td>
                <td><?= e($request['from_branch']) ?></td>
                <td><?= e($request['to_branch']) ?></td>
                <td><?= e($request['requested_by_name']) ?></td>
                <td><span class="badge"><?= e($request['status']) ?></span></td>
                <td><?= e($request['created_at']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

<h1>Create Staff Account</h1>
<p class="muted">Create librarian, branch manager, or admin accounts directly.</p>

<?php if ($flash): ?>
    <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>

<form method="post" class="form-card">
    <label>Name</label>
    <input type="text" name="name" required maxlength="100">

    <label>Email</label>
    <input type="email" name="email" required maxlength="100">

    <label>Phone</label>
    <input type="text" name="phone" required maxlength="20">

    <label>Password</label>
    <input type="password" name="password" required minlength="6">

    <label>Role</label>
    <select name="role" required>
        <option value="librarian">Librarian</option>
        <option value="branch_manager">Branch Manager</option>
        <option value="admin">Admin</option>
    </select>

    <label>Branch</label>
    <select name="branch_id">
        <option value="0">No branch / Platform Admin</option>
        <?php foreach ($branches as $branch): ?>
            <option value="<?= e($branch['id']) ?>"><?= e($branch['name']) ?></option>
        <?php endforeach; ?>
    </select>

    <button type="submit" class="btn">Create Account</button>
</form>

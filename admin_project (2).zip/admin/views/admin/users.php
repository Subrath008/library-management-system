<h1>User Management</h1>
<p class="muted">View, search, activate/deactivate, and change roles of all users.</p>

<?php if ($flash): ?>
    <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>

<script>window.currentAdminId = <?= (int)$_SESSION['user_id'] ?>;</script>

<div class="toolbar">
    <input type="text" id="userSearch" placeholder="Live search by name, email, phone, or role">
    <a class="btn" href="create_staff.php">Create Staff Account</a>
</div>

<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Role</th>
                <th>Branch</th>
                <th>Status</th>
                <th>Change Role</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="userTableBody">
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= e($user['id']) ?></td>
                    <td><?= e($user['name']) ?></td>
                    <td><?= e($user['email']) ?></td>
                    <td><?= e($user['phone']) ?></td>
                    <td><?= e($user['role']) ?></td>
                    <td><?= e($user['branch_name'] ?? '-') ?></td>
                    <td><?= $user['is_active'] ? '<span class="badge success">Active</span>' : '<span class="badge danger">Inactive</span>' ?></td>
                    <td>
                        <form method="post" class="inline-form">
                            <input type="hidden" name="user_id" value="<?= e($user['id']) ?>">
                            <select name="role" required>
                                <?php foreach (['member','librarian','branch_manager','admin'] as $role): ?>
                                    <option value="<?= e($role) ?>" <?= $user['role'] === $role ? 'selected' : '' ?>><?= e($role) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" name="change_role" class="btn small">Save</button>
                        </form>
                    </td>
                    <td>
                        <?php if ((int)$user['id'] !== (int)$_SESSION['user_id']): ?>
                            <?php if ($user['is_active']): ?>
                                <a class="btn danger small" href="users.php?action=deactivate&id=<?= e($user['id']) ?>">Deactivate</a>
                            <?php else: ?>
                                <a class="btn success small" href="users.php?action=activate&id=<?= e($user['id']) ?>">Activate</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="muted">Current admin</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

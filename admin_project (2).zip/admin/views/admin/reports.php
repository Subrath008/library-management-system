<h1>Platform-Wide Reports</h1>
<p class="muted">Reports are generated from the shared database tables.</p>

<section class="report-grid">
    <div class="report-box">
        <h2>Total Borrows Per Month</h2>
        <?php include __DIR__ . '/partials/monthly_borrows.php'; ?>
    </div>
    <div class="report-box">
        <h2>Total Fines Collected Per Month</h2>
        <?php include __DIR__ . '/partials/monthly_fines.php'; ?>
    </div>
    <div class="report-box">
        <h2>Most Active Branches</h2>
        <?php include __DIR__ . '/partials/active_branches.php'; ?>
    </div>
    <div class="report-box">
        <h2>Most Borrowed Genres</h2>
        <?php include __DIR__ . '/partials/borrowed_genres.php'; ?>
    </div>
    <div class="report-box">
        <h2>Member Growth Trend</h2>
        <?php include __DIR__ . '/partials/member_growth.php'; ?>
    </div>
</section>

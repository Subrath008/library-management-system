<h1>Admin Dashboard</h1>
<p class="muted">Platform-wide overview of the library system.</p>

<div class="cards">
    <div class="card"><span>Total Members</span><strong><?= e($stats['total_members']) ?></strong></div>
    <div class="card"><span>Total Books</span><strong><?= e($stats['total_books']) ?></strong></div>
    <div class="card"><span>Total Branches</span><strong><?= e($stats['total_branches']) ?></strong></div>
    <div class="card"><span>Active Loans</span><strong><?= e($stats['active_loans']) ?></strong></div>
    <div class="card"><span>Overdue Loans</span><strong><?= e($stats['overdue_loans']) ?></strong></div>
    <div class="card"><span>Outstanding Fines</span><strong><?= number_format((float)$stats['outstanding_fines'], 2) ?></strong></div>
    <div class="card"><span>Pending Transfers</span><strong><?= e($stats['pending_transfers']) ?></strong></div>
</div>

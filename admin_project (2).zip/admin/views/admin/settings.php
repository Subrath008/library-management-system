<h1>Policies / Settings</h1>
<p class="muted">Using the existing shared SQL, admin can configure lending policy values for branches.</p>

<?php if ($flash): ?>
    <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>

<div class="table-wrap">
<table>
    <thead>
        <tr>
            <th>Branch</th>
            <th>Max Borrow Days</th>
            <th>Max Books/Member</th>
            <th>Fine Rate/Day</th>
            <th>Max Renewals</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($policies as $policy): ?>
            <tr>
                <form method="post">
                    <td><?= e($policy['branch_name']) ?></td>
                    <td><input type="number" name="max_borrow_days" value="<?= e($policy['max_borrow_days']) ?>" min="1" required></td>
                    <td><input type="number" name="max_books_per_member" value="<?= e($policy['max_books_per_member']) ?>" min="1" required></td>
                    <td><input type="number" step="0.01" name="fine_rate_per_day" value="<?= e($policy['fine_rate_per_day']) ?>" min="0" required></td>
                    <td><input type="number" name="max_renewals" value="<?= e($policy['max_renewals']) ?>" min="0" required></td>
                    <td>
                        <input type="hidden" name="policy_id" value="<?= e($policy['id']) ?>">
                        <button type="submit" name="update_policy" class="btn small">Save</button>
                    </td>
                </form>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

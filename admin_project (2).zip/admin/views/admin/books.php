<h1>Global Catalog</h1>
<p class="muted">Admin can view and edit master book catalog records.</p>

<?php if ($flash): ?>
    <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>

<?php if ($editBook): ?>
<form method="post" class="form-card wide">
    <h2>Edit Book #<?= e($editBook['id']) ?></h2>
    <input type="hidden" name="book_id" value="<?= e($editBook['id']) ?>">

    <label>Title</label>
    <input type="text" name="title" value="<?= e($editBook['title']) ?>" required>

    <label>Author</label>
    <input type="text" name="author" value="<?= e($editBook['author']) ?>" required>

    <label>ISBN</label>
    <input type="text" name="isbn" value="<?= e($editBook['isbn']) ?>">

    <label>Genre</label>
    <select name="genre_id" required>
        <?php foreach ($genres as $genre): ?>
            <option value="<?= e($genre['id']) ?>" <?= (int)$editBook['genre_id'] === (int)$genre['id'] ? 'selected' : '' ?>><?= e($genre['name']) ?></option>
        <?php endforeach; ?>
    </select>

    <label>Publisher</label>
    <input type="text" name="publisher" value="<?= e($editBook['publisher']) ?>">

    <label>Published Year</label>
    <input type="number" name="published_year" value="<?= e($editBook['published_year']) ?>" min="1000" max="2099">

    <label>Description</label>
    <textarea name="description" rows="4"><?= e($editBook['description']) ?></textarea>

    <label>Status</label>
    <select name="is_available">
        <option value="1" <?= $editBook['is_available'] ? 'selected' : '' ?>>Available</option>
        <option value="0" <?= !$editBook['is_available'] ? 'selected' : '' ?>>Unavailable</option>
    </select>

    <button type="submit" name="update_book" class="btn">Update Book</button>
    <a href="books.php" class="btn secondary">Cancel</a>
</form>
<?php endif; ?>

<div class="table-wrap">
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>ISBN</th>
            <th>Genre</th>
            <th>Year</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($books as $book): ?>
            <tr>
                <td><?= e($book['id']) ?></td>
                <td><?= e($book['title']) ?></td>
                <td><?= e($book['author']) ?></td>
                <td><?= e($book['isbn']) ?></td>
                <td><?= e($book['genre_name'] ?? '-') ?></td>
                <td><?= e($book['published_year']) ?></td>
                <td><?= $book['is_available'] ? '<span class="badge success">Available</span>' : '<span class="badge danger">Unavailable</span>' ?></td>
                <td><a class="btn small" href="books.php?edit=<?= e($book['id']) ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

ADMIN MODULE SETUP GUIDE

1. Start XAMPP.
2. Start Apache and MySQL.
3. Open phpMyAdmin: http://localhost/phpmyadmin
4. Create database: library_management_system
5. Import your uploaded library_management_system.sql file.
6. Copy the whole admin folder into:
   C:\xampp\htdocs\admin
7. Open browser:
   http://localhost/admin
   or
   http://localhost/admin/public/login.php
8. Login:
   Email: admin@gmail.com
   Password: 123456

IMPORTANT NOTES:
- This admin module uses the existing shared SQL tables.
- No extra database tables were added.
- The AJAX requirement is implemented in: public/ajax/user_search.php
- The JavaScript AJAX code is in: public/assets/js/admin.js
- The audit log is saved in a simple file: storage/audit.log
- The sample SQL stores password_hash as plain text, so this module supports that.

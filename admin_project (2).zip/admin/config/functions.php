<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect($path)
{
    header('Location: ' . $path);
    exit;
}

function require_admin()
{
    if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
        redirect('login.php');
    }
}

function set_flash($type, $message)
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function get_flash()
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

function password_matches_existing_sql($plainPassword, $storedPassword)
{
    // The uploaded SQL file stores sample passwords as plain text: 123456.
    // This keeps admin login compatible with the existing group database.
    if ($plainPassword === $storedPassword) {
        return true;
    }

    // Also supports hashed passwords if another group member later uses password_hash().
    return password_verify($plainPassword, $storedPassword);
}

function log_action($action)
{
    $userId = $_SESSION['user_id'] ?? 'guest';
    $userName = $_SESSION['name'] ?? 'Guest';
    $time = date('Y-m-d H:i:s');
    $line = "[$time] User ID: $userId | $userName | $action" . PHP_EOL;

    $logFile = __DIR__ . '/../storage/audit.log';
    file_put_contents($logFile, $line, FILE_APPEND);
}

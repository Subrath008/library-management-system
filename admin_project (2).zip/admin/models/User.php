<?php
require_once __DIR__ . '/../config/database.php';

class User
{
    public static function findByEmail($email)
    {
        $conn = db();
        $stmt = $conn->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public static function countsByRole()
    {
        $conn = db();
        $sql = "SELECT role, COUNT(*) AS total FROM users GROUP BY role";
        $result = $conn->query($sql);
        $counts = ['member' => 0, 'librarian' => 0, 'branch_manager' => 0, 'admin' => 0];
        while ($row = $result->fetch_assoc()) {
            $counts[$row['role']] = (int)$row['total'];
        }
        return $counts;
    }

    public static function all($keyword = '')
    {
        $conn = db();
        if ($keyword !== '') {
            $search = '%' . $keyword . '%';
            $stmt = $conn->prepare("SELECT u.*, b.name AS branch_name
                                    FROM users u
                                    LEFT JOIN branches b ON u.branch_id = b.id
                                    WHERE u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR u.role LIKE ?
                                    ORDER BY u.id DESC");
            $stmt->bind_param('ssss', $search, $search, $search, $search);
        } else {
            $stmt = $conn->prepare("SELECT u.*, b.name AS branch_name
                                    FROM users u
                                    LEFT JOIN branches b ON u.branch_id = b.id
                                    ORDER BY u.id DESC");
        }
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function createStaff($name, $email, $phone, $password, $role, $branchId)
    {
        $conn = db();

        // Compatibility with the uploaded SQL: sample passwords are stored as plain text.
        // If your group later uses password_verify(), change this line to: password_hash($password, PASSWORD_DEFAULT)
        $passwordValue = $password;

        $stmt = $conn->prepare("INSERT INTO users (name, email, password_hash, phone, role, branch_id, is_active)
                                VALUES (?, ?, ?, ?, ?, ?, 1)");
        $stmt->bind_param('sssssi', $name, $email, $passwordValue, $phone, $role, $branchId);
        return $stmt->execute();
    }

    public static function emailExists($email)
    {
        $conn = db();
        $stmt = $conn->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        return $stmt->get_result()->num_rows > 0;
    }

    public static function setActive($id, $status)
    {
        $conn = db();
        $stmt = $conn->prepare('UPDATE users SET is_active = ? WHERE id = ?');
        $stmt->bind_param('ii', $status, $id);
        return $stmt->execute();
    }

    public static function changeRole($id, $role)
    {
        $conn = db();
        $stmt = $conn->prepare('UPDATE users SET role = ? WHERE id = ?');
        $stmt->bind_param('si', $role, $id);
        return $stmt->execute();
    }
}

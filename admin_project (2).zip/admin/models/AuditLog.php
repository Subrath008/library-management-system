<?php
class AuditLog
{
    public static function lines()
    {
        $file = __DIR__ . '/../storage/audit.log';
        if (!file_exists($file)) {
            return [];
        }
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        return array_reverse($lines ?: []);
    }
}

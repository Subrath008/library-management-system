<?php
require_once __DIR__ . '/../config/database.php';

class Announcement
{
    public static function platformWide()
    {
        $conn = db();
        $stmt = $conn->prepare("SELECT a.*, u.name AS author_name
                                FROM announcements a
                                LEFT JOIN users u ON a.author_id = u.id
                                WHERE a.branch_id IS NULL
                                ORDER BY a.published_at DESC");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function create($authorId, $title, $body)
    {
        $conn = db();
        $branchId = null;
        $stmt = $conn->prepare('INSERT INTO announcements (branch_id, author_id, title, body) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('iiss', $branchId, $authorId, $title, $body);
        return $stmt->execute();
    }

    public static function delete($id)
    {
        $conn = db();
        $stmt = $conn->prepare('DELETE FROM announcements WHERE id = ? AND branch_id IS NULL');
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}

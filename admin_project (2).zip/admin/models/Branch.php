<?php
require_once __DIR__ . '/../config/database.php';

class Branch
{
    public static function all()
    {
        $conn = db();
        $stmt = $conn->prepare("SELECT b.*, m.name AS manager_name,
                                COUNT(l.id) AS librarian_count
                                FROM branches b
                                LEFT JOIN users m ON b.manager_id = m.id
                                LEFT JOIN users l ON l.branch_id = b.id AND l.role = 'librarian'
                                GROUP BY b.id
                                ORDER BY b.id ASC");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function activeBranches()
    {
        $conn = db();
        $stmt = $conn->prepare('SELECT id, name FROM branches WHERE is_active = 1 ORDER BY name');
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function policies()
    {
        $conn = db();
        $stmt = $conn->prepare("SELECT p.*, b.name AS branch_name
                                FROM branch_policies p
                                INNER JOIN branches b ON p.branch_id = b.id
                                ORDER BY b.name");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function updatePolicy($policyId, $maxBorrowDays, $maxBooks, $fineRate, $maxRenewals)
    {
        $conn = db();
        $stmt = $conn->prepare('UPDATE branch_policies
                                SET max_borrow_days = ?, max_books_per_member = ?, fine_rate_per_day = ?, max_renewals = ?
                                WHERE id = ?');
        $stmt->bind_param('iidii', $maxBorrowDays, $maxBooks, $fineRate, $maxRenewals, $policyId);
        return $stmt->execute();
    }
}

<?php
require_once __DIR__ . '/../config/database.php';

class Report
{
    public static function monthlyBorrows()
    {
        $conn = db();
        $stmt = $conn->prepare("SELECT DATE_FORMAT(borrow_date, '%Y-%m') AS month, COUNT(*) AS total
                                FROM borrow_records
                                WHERE borrow_date IS NOT NULL
                                GROUP BY DATE_FORMAT(borrow_date, '%Y-%m')
                                ORDER BY month DESC");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function monthlyFinesCollected()
    {
        $conn = db();
        $stmt = $conn->prepare("SELECT DATE_FORMAT(paid_at, '%Y-%m') AS month, COALESCE(SUM(amount), 0) AS total
                                FROM fines
                                WHERE is_paid = 1 AND paid_at IS NOT NULL
                                GROUP BY DATE_FORMAT(paid_at, '%Y-%m')
                                ORDER BY month DESC");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function mostActiveBranches()
    {
        $conn = db();
        $stmt = $conn->prepare("SELECT br.name AS branch_name, COUNT(r.id) AS total_borrows
                                FROM branches br
                                LEFT JOIN borrow_records r ON br.id = r.branch_id
                                GROUP BY br.id
                                ORDER BY total_borrows DESC");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function mostBorrowedGenres()
    {
        $conn = db();
        $stmt = $conn->prepare("SELECT g.name AS genre_name, COUNT(r.id) AS total_borrows
                                FROM genres g
                                LEFT JOIN books b ON g.id = b.genre_id
                                LEFT JOIN borrow_records r ON b.id = r.book_id
                                GROUP BY g.id
                                ORDER BY total_borrows DESC");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function memberGrowth()
    {
        $conn = db();
        $stmt = $conn->prepare("SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, COUNT(*) AS total_members
                                FROM users
                                WHERE role = 'member'
                                GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                                ORDER BY month DESC");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function interBranchRequests()
    {
        $conn = db();
        $stmt = $conn->prepare("SELECT r.*, b.title AS book_title, fb.name AS from_branch, tb.name AS to_branch, u.name AS requested_by_name
                                FROM inter_branch_requests r
                                INNER JOIN books b ON r.book_id = b.id
                                INNER JOIN branches fb ON r.from_branch_id = fb.id
                                INNER JOIN branches tb ON r.to_branch_id = tb.id
                                INNER JOIN users u ON r.requested_by = u.id
                                ORDER BY r.created_at DESC");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}

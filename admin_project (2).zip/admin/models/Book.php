<?php
require_once __DIR__ . '/../config/database.php';

class Book
{
    public static function all()
    {
        $conn = db();
        $stmt = $conn->prepare("SELECT books.*, genres.name AS genre_name
                                FROM books
                                LEFT JOIN genres ON books.genre_id = genres.id
                                ORDER BY books.id DESC");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function find($id)
    {
        $conn = db();
        $stmt = $conn->prepare('SELECT * FROM books WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public static function genres()
    {
        $conn = db();
        $stmt = $conn->prepare('SELECT id, name FROM genres ORDER BY name');
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public static function update($id, $title, $author, $isbn, $genreId, $publisher, $year, $description, $isAvailable)
    {
        $conn = db();
        $stmt = $conn->prepare('UPDATE books
                                SET title = ?, author = ?, isbn = ?, genre_id = ?, publisher = ?, published_year = ?, description = ?, is_available = ?
                                WHERE id = ?');
        $stmt->bind_param('sssisssii', $title, $author, $isbn, $genreId, $publisher, $year, $description, $isAvailable, $id);
        return $stmt->execute();
    }
}

<?php
require_once __DIR__ . '/../config/database.php';

class Dashboard
{
    private static function singleValue($sql, $types = '', $params = [])
    {
        $conn = db();
        $stmt = $conn->prepare($sql);
        if ($types !== '') {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $row = $stmt->get_result()->fetch_row();
        return $row ? $row[0] : 0;
    }

    public static function stats()
    {
        return [
            'total_members' => self::singleValue("SELECT COUNT(*) FROM users WHERE role = 'member'"),
            'total_books' => self::singleValue('SELECT COUNT(*) FROM books'),
            'total_branches' => self::singleValue('SELECT COUNT(*) FROM branches'),
            'active_loans' => self::singleValue("SELECT COUNT(*) FROM borrow_records WHERE status = 'active'"),
            'overdue_loans' => self::singleValue("SELECT COUNT(*) FROM borrow_records WHERE status = 'active' AND due_date < CURDATE()"),
            'outstanding_fines' => self::singleValue('SELECT COALESCE(SUM(amount), 0) FROM fines WHERE is_paid = 0'),
            'pending_transfers' => self::singleValue("SELECT COUNT(*) FROM inter_branch_requests WHERE status = 'pending'")
        ];
    }
}
